﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvcProyectoAlmacen.Models
{
    public class Colegio
    {
        public int Id { get; set; }
        public string NombreColegio { get; set; }
        public string Direccion { get; set; }
        // Other properties...
    }
}
