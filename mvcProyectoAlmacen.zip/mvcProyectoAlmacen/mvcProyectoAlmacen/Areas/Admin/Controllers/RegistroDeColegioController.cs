﻿namespace mvcProyectoAlmacen.Areas.Admin.Controllers
{
    public class RegistroDeColegioController
    {
    }
}
