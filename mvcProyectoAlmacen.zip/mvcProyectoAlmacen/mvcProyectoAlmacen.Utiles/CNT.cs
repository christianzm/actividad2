﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvcProyectoAlmacen.Utiles
{
    public class CNT
    {
        public const string Administrador = "Administrador";

        public const string Cliente = "Cliente";

        public const string Registrado = "Registrado";
    }
}
